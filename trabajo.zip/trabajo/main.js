import './input.css'; // Esto importa tu Tailwind CSS
