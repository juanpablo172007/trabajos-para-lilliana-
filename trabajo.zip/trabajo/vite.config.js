// vite.config.js
export default {
  css: {
    postcss: './postcss.config.js',
  },
};
